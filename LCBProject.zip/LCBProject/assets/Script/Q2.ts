// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class Q2 extends cc.Component {

    start () {
        let a = []
        let b = []
        let v = 0
        this.test(a, b, v)
    }
    /**
     *  时间复杂度
     * @param a 
     * @param b 
     * @param v 
     * @returns 
     */
    test(a: number[], b: number[], v: number) {
        for (let i = 0; i < a.length; i++)   {
            let m = a[i];
            if(m < v) {
                for (let j = 0; j < b.length; j++) {
                    let n = b[j]
                    if(m + n == v){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    // let m = a.length-1
    // let n = b.length-1
    // i    循环次数
    // 0       n
    // 1       n
    // 2       n
    // ……      n
    // m       n
    // 最坏时间复杂度 O(mn)


}
