import Item from "./Item";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Helloworld extends cc.Component {

    @property(cc.EditBox)
    editBoxX: cc.EditBox = null;

    @property(cc.EditBox)
    editBoxY: cc.EditBox = null;

    @property(cc.Node)
    tips: cc.Node = null;

    @property(cc.Node)
    itemPrb: cc.Node = null;

    @property(cc.Node)
    gameNode: cc.Node = null;

    step_x: number = 0
    step_y: number = 0

    itemList: Item[] = [];

    start () {
        // init logic
    }

    onChangeColorX() {
        this.step_x = parseInt(this.editBoxX.string)
        console.log('colorX ==== ', this.step_x)
        if (!this.step_x || this.step_x > 80 || this.step_x < -20) {
            this.showTips('请输入正确数值！')
        } else {
            this.step_x = this.step_x / 100
        }
    }

    onChangeColorY() {
        this.step_y = parseInt(this.editBoxY.string)
        console.log('colorY ==== ', this.step_y)
        if (!this.step_y || this.step_y > 80 || this.step_y < -20) {
            this.showTips('请输入正确数值！')
        } else {
            this.step_y = this.step_y / 100
        }
    }

    showTips(tips: string) {
        this.tips.y = 0;
        this.tips.opacity = 255;
        let labNode: cc.Node = this.tips.getChildByName('lab')
        if (labNode) {
            labNode.getComponent(cc.Label).string = tips;
            cc.tween(this.tips)
                .by(1, { y: 100 })
                .to(0.5, { opacity: 0 })
                .start()
        }
    }

    getItem(x, y) {
        for (let i = 0; i < this.itemList.length; i++) {
            const element = this.itemList[i];
            if (element.getItem(x,y)) {
                return element;
            }
        }
    }

    getRate(x, y) {
        let rate = [0.2, 0.2, 0.2, 0.2, 0.2];
        if (x - 1 == 0 && y - 1 == 0) {}
        if(x-1 == 0 && y-1 > 0) {
            let temp = this.getItem(x, y-1);
            let temp_c = temp.getColorType();
            // let temp_r = temp.getColorRate();
            console.log('temp_c = ', temp_c)
            let a = rate[temp_c] + this.step_x;
            let b = (1 - a) / 4
            for (let i = 0; i < rate.length; i++) {
                if (i == temp_c) {
                    rate[i] = a;
                } else {
                    rate[i] = b;
                }
            }
        }
        if(x-1 > 0 && y-1 == 0) {
            let temp = this.getItem(x-1, y);
            let temp_c = temp.getColorType();
            // let temp_r = temp.getColorRate();
            console.log('temp_c = ', temp_c)
            let a = rate[temp_c] + this.step_x;
            let b = (1 - a) / 4
            for (let i = 0; i < rate.length; i++) {
                if (i == temp_c) {
                    rate[i] = a;
                } else {
                    rate[i] = b;
                }
            }
        }
        if(x-1 > 0 && y-1 > 0) {
            let temp_1 = this.getItem(x, y-1);
            let temp_2 = this.getItem(x-1, y);
            let temp_1_c = temp_1.getColorType();
            let temp_2_c = temp_2.getColorType();
            if (temp_1_c == temp_2_c) {
                let a = rate[temp_1_c] + this.step_y;
                let b = (1 - a) / 4
                for (let i = 0; i < rate.length; i++) {
                    if (i == temp_1_c) {
                        rate[i] = a;
                    } else {
                        rate[i] = b;
                    }
                }
            } else {
                let a = rate[temp_1_c] + this.step_x;
                let b = rate[temp_2_c] + this.step_x
                let c = (1 - a - b) / 3
                for (let i = 0; i < rate.length; i++) {
                    if (i == temp_1_c) {
                        rate[i] = a;
                    } else if(i == temp_2_c) {
                        rate[i] = b;
                    } else {
                        rate[i] = c;
                    }
                }
            }
        }

        console.log('xy = ', x + ',' + y)
        console.log('rate = ', rate)
        return rate;
    }

    onClick() {
        this.itemList.forEach(element => {
            element.node.parent = null;
            element.node.destroy();
        });
        this.itemList.splice(0);
        for (let x = 1; x < 11; x++) {
            for (let y = 1; y < 11; y++) {
                let item: cc.Node = cc.instantiate(this.itemPrb);
                item.x = -200 + y * 50;
                item.y = 300 - x * 50;
                item.parent = this.gameNode;
                let logic: Item = item.getComponent(Item);
                let rate = this.getRate(x, y);
                logic.init(x, y, rate)
                this.itemList.push(logic)
            }
        }
    }
}
