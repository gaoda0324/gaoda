// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

export enum ColorType {
    RED = 0,
    YELLOW,
    GREEN,
    BLUE,
    ORANGE,
}

const {ccclass, property} = cc._decorator;

@ccclass
export default class Item extends cc.Component {
    @property(cc.Label)
    pos: cc.Label = null;
    // LIFE-CYCLE CALLBACKS:
    x:number = 0
    y:number = 0
    colorType: ColorType = ColorType.RED
    rate: number[] = [0.2, 0.2, 0.2, 0.2, 0.2]
    colorList = [cc.Color.RED, cc.Color.YELLOW, cc.Color.GREEN, cc.Color.BLUE, cc.Color.ORANGE];
    // onLoad () {}

    start () {

    }

    init(x, y, rate) {
        this.x = x;
        this.y = y;
        this.rate = rate;
        this.colorType = this.getNodeColor();
        this.node.color = this.colorList[this.colorType];
        this.pos.string = x + ',' + y;
    }

    getItem(x, y) {
        if (x == this.x && y == this.y) {
            return true;
        }
    }

    getColorType() {
        return this.colorType;
    }

    getColorRate() {
        return this.rate;
    }

    getNodeColor() {
        let random = Math.random();
        for (let idx = 0; idx < 5; idx++) {
            let add = 0;
            for (let i = 0; i <= idx; i++) {
                add += this.rate[i]
            }
            if (random < add) {
                return idx;
            }
        }
        // return 0;
    }
}
